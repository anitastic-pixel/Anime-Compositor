# Architecture RFC and technology selection

Version 0.1 | 2026-09-05 | Proposed baseline

## RFC status

PROPOSED; no framework or language is selected. Start with an offline desktop application and keep the rendering core independent of the UI. Evaluate two bounded alternatives: a native C++/Qt UI with a native render core, and a Rust core with a desktop UI candidate selected during the spike. These are experiment candidates, not performance or productivity claims.

Score the same small prototype on timeline interaction, GPU texture presentation, image decoding, deterministic export, build reproducibility, debugging effort, packaging and license obligations. Qt's available license paths require module-specific review [S-05]. Do not choose a stack merely because a coding agent produces a convincing demo.

## Module boundaries

Document model owns compositions, assets, layer IDs, properties and serializable edits. Command layer validates changes and owns undo/redo. UI reads model snapshots and issues commands; it never mutates rendering state directly.

Evaluator turns a composition, time and quality request into an acyclic dependency plan. Renderer executes the plan. Media service owns decoded frame access and interpretation. Cache owns bounded reusable results. Persistence owns versioning and atomic project writes. Export service evaluates immutable job snapshots.

The same evaluator and effect contracts must serve preview and export. Interactive scheduling may cancel stale preview requests, but exported frames must use a fixed job specification and final-quality settings.

## Dependency direction

UI depends on commands and public model interfaces. Evaluation depends on the model and effect registry. Renderer depends on evaluation requests, image buffers and approved platform backends. Persistence translates schema records to the model and must not depend on UI widgets.

Use stable IDs across interfaces. Avoid passing widget objects, mutable project pointers or unvalidated file paths into worker tasks. Keep platform-specific GPU handles behind a narrow resource interface.

---

## Concurrency and ownership

One controlled command path commits document edits. Workers consume immutable snapshots. Each preview request carries a document revision and cancellation token; the viewer ignores results for obsolete revisions. Resource ownership must make cancellation and teardown safe.

Export should run independently of live editing using a captured revision and media manifest. For G1, a read-only project snapshot plus an export worker is sufficient; a separate process is an experiment if crash isolation justifies the added complexity.

## Core request contracts

FrameRequest: composition ID, rational time, project revision, quality, render scale and output interpretation. FrameResult: image handle, extent, alpha mode, color-space tag, warnings and provenance key. Never return an untagged buffer across a module boundary.

CommandResult: accepted or rejected, new revision, reversible change and diagnostics. LoadResult: parsed version, model or recoverable errors, unsupported fields and missing media. ExportResult: job status, completed frame list and error details.

## G0 experiments

SP-01: save and reopen a minimal document; interrupt the save and verify the old file. SP-02: composite known alpha fixtures through CPU reference math and a candidate GPU path. SP-03: present a cached 1080p frame while scrubbing a small timeline. SP-04: render a fixed sequence twice and compare decoded pixels.

Record compiler, OS, GPU, driver, dependency versions, timings and observed defects. Limit experiments to the minimum code needed to answer the question. Delete or quarantine throwaway code before production integration.

## Decision rule

Reject any candidate that cannot satisfy data safety, color correctness, a maintainable dependency license path or reproducible local builds. Among viable candidates, select the one Ani can sustain with the available engineering support. Preserve a CPU reference path for numeric verification, not a second full production renderer unless justified.

Related documents: 07–11, 13–15. Sources: S-05 for Qt licensing only; module design and experiment criteria are proposals.
