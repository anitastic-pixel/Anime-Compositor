# Product requirements and acceptance matrix

Version 0.1 | 2026-09-05 | Proposed baseline

## Requirement contract

All requirements below are PROPOSED. M denotes the initial 2D MVP; N denotes the next 2.5D stage; L denotes later work. A requirement is complete only when its observable acceptance condition is demonstrated and the evidence is attached to its task. Test details are in 11; implementation tasks are in 15.

## Media, time and editing

R-01 / M / Import: group a selected PNG sequence using an explicit numeric pattern; show dimensions, numbering gaps and frame interpretation. T-01; B-03.

R-02 / M / Exposure timing: map composition frames to drawing IDs with explicit holds. A 1–1–2–2–2 pattern must remain unchanged through save, preview and export. T-02; B-04.

R-03 / M / Layers: add, remove, reorder, rename, lock and hide raster layers; animate 2D position, anchor, scale, rotation and opacity with hold and linear interpolation. T-03; B-05.

R-04 / M / Masks and mattes: support one closed polygon mask per layer and an alpha matte referencing another eligible layer. Define visibility and dependency behavior and reject cycles. T-04; B-06. Feathered Bezier masks and luma mattes are later additions.

R-05 / M / Effects: evaluate an ordered stack containing exposure, Gaussian blur and solid-color tint. Parameters, bounds, alpha and working-space behavior follow document 09. T-05; B-07.

R-06 / M / Preview: provide frame stepping, work-area playback, resolution selection and visible cache state. Show when preview quality differs from final export. T-06; B-08.

R-07 / M / Editing safety: group each user action into a reversible command; undo/redo must restore values, references and dirty state correctly. T-03 and T-07; B-05 and B-09.

---

## Persistence and delivery

R-08 / M / Projects: versioned save, reopen, relative media references, explicit relink and recoverable autosave. Interrupted saves must preserve the last successful project. T-07; B-09.

R-09 / M / Export: render a declared inclusive frame range to a PNG sequence with chosen bit depth, naming and alpha policy; report failure and support cancellation between frames. T-08; B-10.

R-10 / M / Color and alpha: explicit input interpretation and a documented working/output path; checkerboard and alpha-only inspection must not alter export. Numeric alpha and color fixtures pass. T-04 and T-09; B-02 and B-10.

R-11 / M / Offline workflow: create, edit, save and export the reference shot without authentication or network connectivity. No project content leaves the device by default. T-10; B-11.

## Next-stage requirements

R-12 / N / 2.5D: one perspective camera, flat planes, parent transforms and documented transparency ordering. A reference parallax shot reproduces after reopening. T-11; B-13.

R-13 / N / Expressions: a documented native property-expression subset with deterministic time and seeded randomness, bounded evaluation and cycle errors. T-12; B-14. AE syntax translation is separate later research.

R-14 / L / Packaging: collect permitted media, include hashes and usage information, and verify reopening from a new path. T-13; B-15.

R-15 / L / Handoff: evaluate EXR and WAV first, then layered artwork and review-video formats based on actual artist need and dependency review. Each format needs its own conformance fixtures. T-14; B-16.

## Quality requirements

Q-01: no known reproducible project corruption in the release candidate; T-07. Q-02: satisfy the declared reference performance envelope; T-06. Q-03: document and test keyboard access for the complete W-01 workflow, readable focus and 100–200% display scaling; T-15. Q-04: distributable builds have a dependency/provenance record, notices and a recorded license review; T-16.

Unknown native files, unsupported effects and missing media must produce explicit diagnostics, not a false fidelity claim. Later requirements are roadmap entries and do not block the initial MVP. Related documents: 04, 07–11 and 15.
