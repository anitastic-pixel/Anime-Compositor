# Initial implementation backlog and task briefs

Version 0.1 | 2026-09-05 | Proposed baseline

## Backlog rules

Status for all tasks is NOT STARTED. Sequence reflects dependencies, not calendar commitments. Each task must attach test evidence and update the relevant contract before closure. The first implementation task is B-02 after G0 decisions; B-01 is a feasibility and specification task.

B-01 / G0: resolve initial decisions, select rights-cleared fixtures, run SP-01–SP-04 and write the stack decision. Dependencies: D-01–D-07 to the extent needed by each experiment. Exit: evidence-backed architecture choice and approved render/time contracts.

B-02 / R-10: implement tagged image buffers and CPU normal-over reference math. Depends B-01. Exit: T-04 numeric basics and T-09 color/alpha fixtures; no UI required.

B-03 / R-01: PNG import and sequence manifest. Depends B-02. Exit: T-01 with gaps, mismatches and Unicode paths. No video decoder or layered-file import.

B-04 / R-02: rational time and explicit exposure spans. Depends B-03. Exit: T-02 matches all expected drawing IDs and frame ranges.

B-05 / R-03,R-07: model commands, layer order, transforms, interpolation and undo. Depends B-04. Exit: T-03 and exact model restoration. Implement a minimal editing surface sufficient for inspection.

B-06 / R-04: polygon mask, alpha matte references and cycle validation. Depends B-05. Exit: T-04 visual and dependency cases, including matte-only visibility.

B-07 / R-05: effect registry and the three G1 effects. Depends B-06. Exit: T-05 plus bounds and serialization contracts. Do not add optional effects in this task.

---

## Completing the first usable release

B-08 / R-06,Q-02: viewer, frame stepping, work area and bounded cache. Depends B-07. Exit: T-06 with measured cold/warm results and correct invalidation.

B-09 / R-07,R-08,Q-01: versioned persistence, relink, manual save, autosave and recovery UI. Depends B-05 and stable effect records from B-07. Exit: T-07 including interrupted and disk-full writes.

B-10 / R-09,R-10: immutable export snapshot and PNG sequence writer. Depends B-07,B-09. Exit: T-08/T-09 with correct range, naming, color, cancellation and error state.

B-11 / R-11,Q-03,Q-04: package the offline application, complete keyboard/scaling checks and dependency notices. Depends B-08–B-10. Exit: T-10,T-15,T-16 and clean-environment smoke test.

B-12 / G1 acceptance: Ani completes W-01/W-02; fix blocking usability defects and publish the supported envelope. Depends B-11. Exit: applicable G1 gate and recorded artistic review. No universal compatibility or speed claims.

## Next and later tasks

B-13 / R-12: flat-plane camera, parenting and explicit ordering. Depends B-12,D-09. Exit: T-11/W-04. B-14 / R-13: bounded native expressions. Depends B-12,D-10. Exit: T-12. These do not block G1.

B-15 / R-14: collect project/media with permissions and a manifest. Depends stable schema and validated need. Exit: T-13. B-16 / R-15: add one format at a time after discovery and dependency review. Exit: the corresponding T-14 fixtures.

## Definition of ready and done

Ready: requirement, input fixture, expected behavior, prerequisites and legal/dependency status are understood. Done: implementation works, relevant tests pass, manual artistic review occurs where needed, documentation matches and the change is reviewable. A mock or partial UI is not completion.

For the first coding session, use the B-02 brief in 12; do not ask an agent to build the entire pack in one prompt. The complete dependency chain is deliberately narrow enough to reveal rendering and data-model errors before a large interface hides them.
