# Scope, roadmap and anti-bloat policy

Version 0.1 | 2026-09-05 | Proposed baseline

## Scope tiers

Stage G0: planning and feasibility. Select the reference shot, evaluate persistence and color contracts, compare bounded stack options and record measured results. No full editor is required to answer these questions.

Stage G1: a useful 2D compositor. Deliver R-01 through R-11: PNG input/output, held-frame timing, a layer stack, basic transforms, masks, alpha mattes, three effects, preview, undo and durable projects. Restrict the initial blend catalog to normal, multiply, screen and add, with documented math.

Stage G2: the 2.5D promise. Deliver R-12 and R-13 after G1: flat planes, camera, parenting and native bounded expressions. Add curve editing only after interpolation and serialization contracts are extended and tested.

Stage G3: production convenience. Consider precompositions, adjustment layers, richer mask tools, EXR, WAV reference audio, packaging, batch rendering, effect presets and selected anime-specific processing. Prioritize by observed shot work, not catalog size.

## Explicit exclusions from G1

No drawing engine, vector animation suite, skeletal character rigging, motion capture, full 3D scene renderer, video editing timeline, advanced tracking, rotoscoping automation, generative AI, asset store, collaboration service or mobile port.

No .aep importer, AE binary plugin host, comprehensive AE expression engine or cloned commercial effect catalog. These are separate compatibility products with independent technical and legal costs.

## Dependencies

Time and alpha contracts precede effect work. Serializable commands precede complex UI interactions. Save/recovery precedes any user trial with irreplaceable artwork. Stable render evaluation and cache keys precede performance optimization. Legal dependency review precedes distributable builds.

G2 depends on passing G1 tests, a camera sampling specification and measured memory headroom. G3 requires evidence of repeated manual effort that the proposed feature would remove.

---

## Feature admission rule

For every addition, write the affected workflow, expected frequency, smallest useful behavior, requirement ID, dependency cost, test fixture and maintenance owner. If it does not enable a blocked workflow or measurably improve a repeated task, keep it in the parking lot.

Compare value with implementation, testing, UI, documentation, migration and ongoing maintenance cost. Do not justify an addition solely because AE has it, a plugin exists or a model can generate the code quickly.

Allow one major subsystem in active development at a time for the proposed solo-led workflow. Avoid introducing several partially working systems to make the roadmap appear faster. If capacity changes, update 13 before increasing work in progress.

## Features to validate before promotion

Precompositions: useful for reusable shot groups, but add time mapping and invalidation complexity. Adjustment layers: convenient for shared looks, but require precise stack scope. Graph editor: valuable only if artists need more than hold and linear curves in the validated scenes.

Anime edge smoothing and line recolor: plausible priorities supported by existing tool categories, but evaluate line preservation and temporal stability first. Particles, complex glows and tracking should wait until representative shots demonstrate the gap.

## Removal and deferral procedure

Record the reason, affected requirements and user-visible consequences in the decision register. Remove abandoned UI entry points and stale documentation. Preserve unknown serialized data where feasible so deferral does not silently damage old projects.

Revisit parked features after G1 acceptance and after each small set of completed real shots. Do not maintain an expanding backlog with no discovery evidence or ownership.

## Release naming

Use prototype, internal alpha and artist alpha labels until objective gates pass. Do not call the first release an industry-standard replacement. The product can retain a long-term AE-alternative ambition while stating precisely what each build supports.

Related documents: 01, 03, 13, 14 and 16.
