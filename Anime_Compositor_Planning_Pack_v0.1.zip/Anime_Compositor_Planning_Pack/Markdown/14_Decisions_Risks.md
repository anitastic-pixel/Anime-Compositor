# Decision, assumption and risk register

Version 0.1 | 2026-09-05 | Proposed baseline

## Decision procedure

Every decision record contains ID, question, options, recommendation, evidence, owner, status, date and affected requirements. All entries below are OPEN with a proposed default; none represents an approval inferred from silence. Ani is the proposed product decision owner; technical/legal reviewers must be assigned where needed.

D-01 / Platform: Windows-first desktop is recommended for initial validation; confirm supported OS and hardware. Affects R-01–R-11 and stack selection. Due before B-01 completion.

D-02 / Initial scope: adopt the 2D G1 milestone before 2.5D G2. Alternative is camera support in the first milestone, with larger integration risk. Affects R-12 and milestone boundaries. Due before implementation backlog commitment.

D-03 / Distribution: choose open-source, free supported core or perpetual commercial model after reviewing maintenance and dependency obligations. Affects Q-04 and dependency choices. Due before dependency commitments that constrain distribution.

D-04 / Capacity: set available hours/week, monthly budget ceiling and reviewer access. No default amount is assumed. Affects schedule and work in progress. Due before calendar estimates.

D-05 / Reference shot: use a rights-cleared 10-second 1080p/24 fps cel shot with mixed holds. Ani selects or supplies artwork. Affects W-01 and performance fixtures. Due before B-12 and preferably at G0.

D-06 / Stack: choose after SP-01–SP-04; no language/framework approved. Affects all code work. Due before production implementation.

---

## Additional decisions

D-07 / Color: adopt document 08's linear float working path and explicit PNG interpretation, or document a justified alternative. Resolve before B-02. D-08 / Compatibility: native features first; translation and binary hosting deferred. Resolve before any compatibility work.

D-09 / G2 geometry: restrict initial 2.5D to non-intersecting planes with explicit order. Resolve before B-13. D-10 / Expressions: choose runtime/language and enforceable limits after a sandbox experiment. Resolve before B-14. D-11 / Naming: working project title only; choose and review a public name before distribution.

## Initial risks

K-01 / High / Scope expansion: effect catalogs displace core reliability. Trigger: feature added without workflow/test. Mitigation: document 04 admission rule. Owner: product.

K-02 / High / Pixel errors: alpha/color mismatch damages edges. Trigger: halos or inconsistent preview/export. Mitigation: T-04/T-09 and tagged buffers. Owner: rendering.

K-03 / High / Data loss: partial writes or migrations damage projects. Trigger: failed recovery fixture. Mitigation: backups, atomic replacement experiments and T-07. Owner: persistence.

K-04 / High / License mismatch: dependency configuration conflicts with distribution. Trigger: unknown license/build flag. Mitigation: block distribution of unresolved component and review 10. Owner: release/legal.

K-05 / High / Maintenance capacity: too many platforms/backends. Trigger: missed gates or growing unresolved defects. Mitigation: one initial platform, narrower release. Owner: product/engineering.

K-06 / Medium / GPU variability: driver-dependent failures. Trigger: inconsistent numeric/performance results. Mitigation: reference math, declared support envelope and targeted hardware testing. Owner: rendering.

K-07 / Medium / Unsafe input: malformed media or expressions exhaust resources. Trigger: unbounded parser/evaluator. Mitigation: size limits, cancellation and sandbox tests. Owner: engineering.

## Assumptions and change log

A-01: supplied conversation excerpts capture goals but not full earlier recommendations. A-02: solo-led development is the planning default. A-03: professional usability needs direct artist validation. Version 0.1 establishes proposals only; all tests remain NOT RUN.

Change record format: date, decision ID, accepted change, reason, affected documents/requirements, owner and evidence. Review risks at each milestone and immediately after a trigger. Related documents: 00, 04, 10, 13 and 15.
