# Product charter and success criteria

Version 0.1 | 2026-09-05 | Proposed baseline

## Problem and audience

CONFIRMED GOAL: create an After Effects alternative centered on compositing digital and traditional 2D animation, including anime. The user wants to approach the project efficiently, consider useful production tools and expressions, address legality and avoid uncontrolled expansion.

The proposed primary audience is an individual animator or compositor finishing short shots from painted backgrounds and transparent cel sequences. Small-team handoffs are a secondary audience. Studio-wide pipeline replacement, a general video editor and a full drawing application are not initial targets.

The user's concern about affordable layer-based alternatives is a motivation, not a verified claim that competing tools do not exist. Document 16 records adjacent tools and research limitations.

## Product promise

PROPOSED: take existing artwork from import through timing, compositing, preview and reliable export without requiring a recurring subscription for the core workflow. Prioritize predictable pixels, recoverable projects and clear controls. A free or perpetual model is a user preference; the funding and license model remain OPEN.

The core demonstration is a 10-second, 1920 × 1080, 24 fps shot with one painted background and several transparent cel sequences. The artist should adjust exposures, transform layers, create masks and mattes, apply a small effect stack, save, reopen and export all 240 frames. This is the MVP scenario, not a promise about every possible project.

## Principles

Preserve drawings and intentional held frames. Keep destructive actions reversible. Show how media, color and cache are interpreted. Make unsupported behavior explicit. Favor a small coherent toolset over a large catalog. Keep saved projects usable without a service account.

Treat familiar compositing concepts as workflow inspiration. Design original branding, documentation and UI assets; do not make pixel-perfect duplication or total compatibility a product objective.

---

## Success measures

MVP completion: the reference shot exports with the intended frame count, timing, alpha and color interpretation; opening the saved project reproduces the approved result. Evidence: T-01 through T-09 in document 11.

Usability: Ani can complete W-01 from document 02, with no developer intervention, after a short introduction. Record completion time, help requests, errors and workaround count. Set an improvement target only after obtaining a baseline; do not invent a percentage improvement over AE.

Reliability: the release candidate passes the recovery and low-resource tests; no known reproducible project-corruption defect remains open. This is a release gate, not a claim of zero defects in production.

Performance: meet document 08's provisional reference-scene targets on the declared machine. Report cold and warm cache results separately; do not extrapolate to untested GPUs or projects.

## Release boundaries

The first useful release includes image-sequence finishing and deterministic export. The following release demonstrates camera-driven parallax with flat planes. This sequencing preserves the 2.5D ambition while reducing the number of unproven systems in the first milestone.

Deferred capabilities include drawing/inking, automatic in-betweening, full character rigging, advanced particles, general 3D rendering, multi-user cloud editing, a plugin marketplace and native AE project import. No public claim of professional studio readiness should precede artist validation and interoperability testing.

## Ownership and unresolved constraints

Ani is the proposed product decision owner and artistic acceptance reviewer. Engineering, legal review and release ownership are roles to assign; this pack does not imply that specialists have been engaged.

OPEN: minimum hardware, hours per week, budget cap, distribution license, target OS beyond the initial proposal and the exact reference artwork. Revisit scope if maintenance exceeds available capacity. Successful completion of a narrow reliable workflow is more valuable than a broad unfinished feature list.

Related documents: 02, 03, 04, 13 and 14.
