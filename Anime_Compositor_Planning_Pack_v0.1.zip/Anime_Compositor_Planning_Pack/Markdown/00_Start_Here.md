# Planning pack: start here

Version 0.1 | 2026-09-05 | Proposed baseline

## Purpose and standing

This is version 0.1 of the Anime Compositor AE Replacement planning baseline, prepared for Ani on 5 September 2026. It contains eighteen coordinated documents and editable Markdown counterparts for future repository use. It is a substantive starting specification, not evidence that an application has been implemented or validated.

The confirmed direction is a focused layer-based 2.5D compositor for anime and other 2D animation, an alternative to subscription-dependent workflows, with consideration of expressions, production effects, legal constraints and scope control. These goals come from the supplied project conversation excerpts. Full earlier assistant replies were unavailable; detailed recommendations in this pack are newly proposed, not recovered agreements.

## How to read the pack

Begin with 01 Charter, 02 Workflows and 03 Requirements. Review 04 Scope and 14 Decisions before authorizing implementation. Engineering should then read 06 Architecture, 07 Project format, 08 Rendering and 11 Verification. Consult 10 Legal before selecting dependencies or implementing compatibility work.

The initial recommendation is a Windows-first, offline desktop application. This is a proposal, not an approved platform decision. The first usable milestone should finish a short 2D shot reliably; a later milestone adds bounded 2.5D camera work. Neither milestone promises broad After Effects compatibility.

## Status vocabulary

CONFIRMED GOAL means explicit user intent visible in the supplied context. PROPOSED means a recommendation awaiting adoption. OPEN means a decision or evidence gap. VERIFIED SOURCE means a limited factual claim checked against a cited primary source. DEFERRED means outside the proposed first release, not permanently rejected.

All numeric performance thresholds, implementation choices and feature priorities are PROPOSED unless explicitly stated otherwise. No benchmarks, artist interviews, code audits or legal clearances have been completed for this project.

## First review

Review D-01 through D-06 in document 14: platform, scope, distribution model, available capacity, reference shot and architecture experiment. Use the initial defaults to conduct reversible research and prototypes; do not turn them into public promises. Development starts from the bounded task in 15 after the relevant decisions and technical gates are satisfied.

---

## Document map

00 Start here: navigation, authority and next action.

01 Product charter: audience, outcome, principles and success.

02 Workflow specification: shot scenarios, inputs, handoffs and failure paths.

03 Product requirements: stable IDs and acceptance criteria.

04 Scope and roadmap: feature tiers, dependencies and anti-bloat rules.

05 UX specification: workspace, interactions and accessibility.

06 Architecture RFC: module boundaries and stack experiments.

07 Project and media specification: persistence, time and interchange.

08 Rendering specification: alpha, color, evaluation and performance.

09 Effects and expressions: contracts, priorities and compatibility limits.

10 Legal and licensing: provenance, review triggers and release evidence.

11 Verification plan: fixtures, tests and measurable quality gates.

12 Development operating guide: AI task boundaries and review discipline.

13 Delivery and sustainability: milestones, capacity and release operations.

14 Decision and risk register: open decisions, risks and change procedure.

15 Initial backlog: sequenced, testable implementation tasks.

16 Production-tool research: verified references and discovery plan.

17 Evidence register: dated primary sources and limitations.

## Authority and maintenance

Charter governs product intent; requirements govern observable behavior; architecture and rendering documents govern implementation contracts. Document 14 records accepted changes and their rationale. A conflict must be resolved explicitly rather than by silently choosing the newest-looking prose. Until Ani adopts this baseline, the detailed documents remain proposals.

A feature change must name affected requirement IDs, tests, dependencies and milestone impact. Update affected documents together and record a version note. Markdown should become the canonical editable source if moved into a repository; regenerate Word review copies after agreed changes. Do not maintain divergent specifications in both formats.

## Pack acceptance

Every proposed initial-release requirement maps to a test or review in 11 and a backlog task in 15. The next planning pass should replace assumptions with a chosen sample shot, a declared reference machine and measured spike results. Professional structure should support work; add another document only when an existing one cannot carry the decision clearly.
