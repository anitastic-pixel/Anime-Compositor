# Delivery, capacity and release plan

Version 0.1 | 2026-09-05 | Proposed baseline

## Planning basis

Dates and cost are OPEN because weekly capacity, budget and engineering support have not been supplied. Use dependency gates rather than a fictional completion date. After G0, estimate each remaining task as a range using measured throughput and the uncertainty of its subsystem.

Track implementation, integration, testing, artistic review and maintenance separately. A model subscription is only one cost category; it does not substitute for engineering time or distribution review.

## Milestones and exit evidence

M0 / Feasibility: D-01 through D-06 resolved sufficiently for implementation; SP-01 through SP-04 reported; reference artwork chosen. Exit: architecture decision, legal dependency screen and a reproducible baseline.

M1 / Internal 2D alpha: B-02 through B-11 complete. Exit: W-01 and applicable G1 tests pass; known limitations are written; save/recovery works. Use original test media and copies of personal artwork.

M2 / Artist alpha: B-12 complete. Exit: Ani finishes W-01 and W-02, priority usability defects are resolved and performance is reported on the declared machine. This is validation of the supported workflow, not studio certification.

M3 / 2.5D alpha: B-13 and B-14 complete. Exit: G2 tests and W-04 pass with documented plane-order and expression limitations. M4 / Production conveniences: select B-15/B-16 and other items only after artist evidence and capacity review.

## Capacity worksheet

Record available hours/week, direct budget/month, review availability and machine access. For each task record low/high effort, dependencies and confidence. Calendar duration follows available capacity and blocked time; do not divide all estimated work by assumed full-time hours.

Reserve explicit effort for regressions and support; choose the reserve after initial defect data exists. Re-estimate at every milestone and when a new dependency changes the architecture.

---

## Cost and sustainability choices

Evaluate free/open-source, free core with optional support and perpetual commercial distribution as distinct models. None is selected. Decide what pays for build infrastructure, signing if used, release hosting, legal review, documentation and ongoing compatibility fixes.

A perpetual license still creates maintenance expectations. Define supported versions, upgrade policy and export/project access before selling anything. Do not add a subscription or cloud dependency to core editing without revisiting the user's stated preference.

## Release procedure

Freeze the candidate revision and dependency versions. Run applicable tests and inspect the actual packaged build on a clean supported environment. Verify installation, first launch, offline operation, save locations, recovery, export and uninstall behavior.

Package notices, known limitations, supported hardware/OS envelope and recovery guidance. Preserve reproducible build instructions, release identifiers and rollback artifacts. For an updater, verify authenticity and failure handling before enabling it; a manual download workflow can precede an updater.

## Support and incident handling

Use a bug report containing build, OS/GPU/driver, reproduction steps, expected/actual result and a minimal permitted project. Remove private paths and artwork unless the user elects to share them. Telemetry and crash uploads are proposed opt-in only, with data minimization.

For suspected corruption: prioritize preserving the original project, collect a copy with consent, document recovery and issue a verified fix. Do not overwrite the user's only copy during investigation.

## Go/no-go record

Release owner: OPEN. Product reviewer: proposed Ani. Record the build, passed gates, accepted limitations, unresolved risks, license review and distribution scope. No gate is currently passed; this document plans future delivery.

If G0 reveals an unsustainable stack or maintenance load, reduce scope or evaluate extending an existing tool before committing to a full independent editor. Related documents: 01, 04, 10–12, 14 and 15.
