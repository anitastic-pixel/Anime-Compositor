# Claude and Codex development operating guide

Version 0.1 | 2026-09-05 | Proposed baseline

## Purpose

This is a proposed repository operating guide for later development. It does not override existing workspace instructions or authorize external actions. It applies equally to AI-assisted and human implementation; exact model subscriptions and tools are outside this specification.

A task begins with a requirement ID, current code evidence, affected contract, bounded outcome and validation method. Read the relevant documents before editing. If the repository disagrees with the planning pack, record the discrepancy rather than silently rewriting either source.

## Session procedure

Inspect repository instructions and working-tree state. Identify the smallest task whose prerequisites are complete. State assumptions and inspect the affected modules. Implement one bounded change, verify the relevant behavior and review the diff for unrelated edits.

Update task status, changed contracts and any new decisions. End with what changed, evidence, limitations and the next task. Never mark a requirement complete because code compiles, a screenshot looks plausible or a mock returns the expected value.

## Task specification

Use this task structure: goal; requirement IDs; relevant files/contracts; prerequisites; allowed scope; out-of-scope work; acceptance criteria; verification; expected deliverables; stop conditions. A task should fit a reviewable change, not an entire application subsystem by default.

Stop to resolve a real contract conflict, unclear destructive operation, unapproved dependency obligation or missing information that materially changes the design. Routine reversible implementation choices can proceed within the task's scope.

## Repository proposal

Keep product and technical specifications under docs/, native code under src/, independent fixtures under tests/fixtures/, benchmark definitions under benchmarks/ and repeatable build helpers under tools/. Choose the final layout after stack selection. The Markdown documents in this pack can seed docs/; they are not existing repository instructions.

---

## Code review checklist

Verify that data ownership, error handling and cancellation follow the architecture contract. Check alpha/color tags, rational time conversion, cache invalidation and schema versioning wherever touched. Reject silent fallback behavior that changes pixels or timing.

Review added dependencies and their provenance. Verify tests exercise observable behavior rather than mirroring implementation. Confirm undo and persistence for new editable properties. Remove scaffolding, invented benchmark claims and dead UI controls.

## Model-assisted work boundaries

Ask the agent to explain uncertainty and show evidence. Require it to distinguish implemented, tested and proposed behavior. Never accept fabricated citations, source licenses or hardware measurements. Do not paste confidential assets into external services without a deliberate authorization decision.

AI assistance may accelerate implementation, but estimates must include debugging, integration, artistic review and maintenance. Keep a stable human product decision owner. Use independent review for especially consequential rendering, persistence or distribution changes when available.

## Example first implementation brief

Task B-02: implement the minimal CPU reference compositor after B-01 approves its contract. Inputs are synthetic tagged RGBA buffers. Output is normal-over composition in linear premultiplied float32. Include transparent, opaque and partial-alpha cases derived independently from the formula in 08.

Do not build the editor, add codecs or optimize GPU kernels in this task. Deliver source, fixtures, passing numeric evidence and an explanation of zero-alpha behavior. If the chosen buffer API cannot carry alpha/color metadata, resolve that contract before proceeding.

## Change and security hygiene

Do not modify unrelated user work. Keep secrets outside projects, logs and examples. Treat project files, media and expressions as untrusted input. Apply parser limits and path validation. Review packages before execution and use reproducible versions.

No automatic release, sharing, telemetry enablement or public compatibility claim follows from finishing a code task. Release work follows the user's authorization and the concrete checks in 13. Related documents: 06–11, 14 and 15.
