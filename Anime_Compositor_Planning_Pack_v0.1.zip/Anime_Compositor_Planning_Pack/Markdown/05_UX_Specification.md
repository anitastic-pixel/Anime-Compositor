# Workspace and interaction specification

Version 0.1 | 2026-09-05 | Proposed baseline

## Proposed workspace

The default workspace has a media bin, central composition viewer, property/effect inspector and bottom timeline. A compact status area shows render progress, cache state and actionable warnings. This is a structural proposal; detailed visual design and usability testing remain open.

The timeline represents layer order and exposure duration. The inspector edits the selected layer or effect. Selection must remain consistent across panels, and a clear indication must distinguish selected, locked and hidden states.

Use original icons, copy and visual styling. Familiar terminology may help learning, but do not trace proprietary screenshots or reproduce distinctive assets.

## Core interaction rules

Dragging a numeric control creates one undoable operation on release. Escape cancels an in-progress edit. Typing a number exposes its unit, allows precision and validates the range. Invalid values keep the previous valid state and explain the issue.

Frame stepping always moves one composition frame. Exposure editing changes the drawing mapping without inadvertently resampling artwork. Moving a keyframe does not change cel timing unless the selected command explicitly operates on both.

Layer reorder previews the resulting position. Deleting a referenced matte requires resolving dependent layers or canceling; never leave hidden stale references. Effect bypass remains separate from deleting an effect.

## Viewer requirements

Provide fit, 100% zoom, pan, checkerboard, alpha-only view and comparison with effect bypass. Overlays must be excluded from render output. The viewer identifies draft resolution and shows the displayed frame number.

Color interpretation is accessible next to asset/project settings. A warning must identify both the problem and the next action: for example, a missing numbered frame with relink access. Avoid generic failure messages that force users to inspect logs.

---

## Keyboard and accessibility

Define a command registry before assigning shortcuts. Support keyboard selection, property entry, frame navigation, undo/redo, save and export. Make shortcuts editable after the baseline is stable; publish an in-app reference.

Keep visible focus, sufficient contrast and labels alongside color-coded status. Verify common dialogs and W-01 at 100%, 150% and 200% scaling. Japanese filenames and Unicode labels must survive editing, save and relink. Screen-reader behavior needs implementation-specific testing; do not claim accessibility compliance from this specification alone.

## States to design explicitly

Empty project: show import and composition creation. Loading: allow safe cancellation and identify the asset. Dirty project: show unsaved state without excessive interruption. Missing media: preserve the layer and offer relink. Unsupported effect: preserve its settings and explain fidelity impact.

Export running: show current frame, completed count and cancellation. Export failed: show a readable cause and output location. Recovery available: distinguish the recovery copy from the last manual save. GPU reset or memory exhaustion: keep the project intact and provide a recoverable workflow where possible.

## Usability evaluation

Use W-01 and W-02 as task scripts. Observe where Ani looks, how often they switch panels, accidental edits and help requests. Record the actual starting configuration and input assets. Compare successive designs using the same tasks.

Proposed acceptance: complete W-01 without developer intervention and with all required controls reachable by keyboard. Treat efficiency targets as open until an observed baseline exists.

## Design deliverables before implementation

Produce a small set of wireframes for import, normal editing, exposure editing, missing-media recovery and export. Define spacing, type scale, state colors and icon provenance. This pack specifies those screens but does not contain a finished visual design or validated prototype.

Related documents: 02, 03, 07, 11 and 15.
